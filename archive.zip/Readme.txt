Please ADD in Row 89:90 Your GMAIL Account

##if u want to use a Telegrambot 
add in row 118 the Telegrambot Token
add in row 119 the telegram chat 
remove /* in row 115 and */ in row 132



